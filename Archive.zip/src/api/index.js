const { Router } = require('express');
const employee = require('./routes/employee');
const inspection = require('./routes/inspection');
const auth = require('./routes/auth');

module.exports = () => {
  const app = Router();
  // Operational
  auth(app);
  employee(app);
  inspection(app);
  return app;
};
