module.exports = {
  employee: {
    create: 'onCreateEmployee',
    update: 'onUpdateEmployee',
    updateIsTracked: 'onUpdateIsTrackedEmployee',
    updatePhoto: 'onUpdatePhotoEmployee',
  },
};
